-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-05-2020 a las 13:19:47
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `practica2definitiva`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `amarre`
--

CREATE TABLE `amarre` (
  `Manga` varchar(3) NOT NULL,
  `Calado` varchar(3) NOT NULL,
  `Identificador` varchar(50) NOT NULL,
  `Geoposición` varchar(50) DEFAULT NULL,
  `TipoEslora` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `amarre`
--

INSERT INTO `amarre` (`Manga`, `Calado`, `Identificador`, `Geoposición`, `TipoEslora`) VALUES
('7m', '2m', '123', '10,17', 'D'),
('7m', '2m', '1A', '10,11', 'C'),
('7m', '2m', '2A', '10,12', 'D'),
('7m', '2m', '3A', '10,13', 'D'),
('7m', '2m', '4A', '10,14', 'D'),
('9m', '3m', '5A', '10,15', 'F'),
('9m', '3m', '6A', '10,16', 'F'),
('10m', '3m', '7A', '10,18', 'G'),
('10m', '3m', '8A', '10,19', 'D');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `barco_motor`
--

CREATE TABLE `barco_motor` (
  `TipoMotor` varchar(25) DEFAULT NULL,
  `Potencia` varchar(25) DEFAULT NULL,
  `Marca` varchar(25) DEFAULT NULL,
  `Matrícula` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `barco_motor`
--

INSERT INTO `barco_motor` (`TipoMotor`, `Potencia`, `Marca`, `Matrícula`) VALUES
('Fuera_borda', '5cv', 'Mercury', 'AAA'),
('Dentro_borda', '4cv', 'Jupiter', 'BBB'),
('Dentro_borda', '15cv', 'Neptuno', 'EEE'),
('Dentro_borda', '15cv', 'Neptuno', 'FFF'),
('Dentro_borda', '15cv', 'Saturno', 'III');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `barco_vela`
--

CREATE TABLE `barco_vela` (
  `TipoVela` varchar(25) DEFAULT NULL,
  `Cantidad` varchar(2) DEFAULT NULL,
  `Matrícula` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `barco_vela`
--

INSERT INTO `barco_vela` (`TipoVela`, `Cantidad`, `Matrícula`) VALUES
('Solent', '2', 'BBB'),
('Reacher', '3', 'CCC'),
('Trinqueta', '1', 'DDD'),
('Trinqueta', '2', 'GGG'),
('Latina', '2', 'HHH'),
('Solent', '2', 'III');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `concesión`
--

CREATE TABLE `concesión` (
  `FechaInicio` date NOT NULL,
  `FechaFinal` date NOT NULL,
  `IDConcesión` varchar(25) NOT NULL,
  `IDLegal` varchar(25) NOT NULL,
  `Identificador` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `concesión`
--

INSERT INTO `concesión` (`FechaInicio`, `FechaFinal`, `IDConcesión`, `IDLegal`, `Identificador`) VALUES
('2020-01-01', '2020-03-03', 'XX1', '11111111A', '1A'),
('2020-05-09', '2020-09-10', 'XX10', '33333333A', '4A'),
('2020-03-09', '2020-10-10', 'XX11', '66666666A', '8A'),
('2020-05-02', '2020-07-02', 'XX2', '22222222A', '2A'),
('2020-03-01', '2020-08-02', 'XX3', '33333333A', '3A'),
('2020-01-01', '2020-10-02', 'XX4', '44444444A', '5A'),
('2020-02-01', '2020-09-09', 'XX5', '44444444A', '6A'),
('2004-02-01', '2007-07-07', 'XX6', '55555555A', '4A'),
('2020-05-01', '2020-08-02', 'XX7', '11111111A', '1A'),
('2020-02-01', '2020-07-07', 'XX8', '33333333A', '123'),
('2016-02-01', '2016-08-07', 'XX9', '33333333A', '7A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `embarcación`
--

CREATE TABLE `embarcación` (
  `Nombre` varchar(25) DEFAULT NULL,
  `TipoBarco` varchar(25) DEFAULT NULL,
  `Matrícula` varchar(25) NOT NULL,
  `Material` varchar(25) DEFAULT NULL,
  `Eslora` varchar(3) NOT NULL,
  `Manga` varchar(3) NOT NULL,
  `Calado` varchar(3) NOT NULL,
  `FechaConstr` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `embarcación`
--

INSERT INTO `embarcación` (`Nombre`, `TipoBarco`, `Matrícula`, `Material`, `Eslora`, `Manga`, `Calado`, `FechaConstr`) VALUES
('Niña', 'Lancha', 'AAA', 'Metal', '5m', '4m', '1m', '2020-08-10'),
('La Pinta', 'Catamarán', 'BBB', 'Fibra de vidrio', '11m', '5m', '0.5', '2019-02-01'),
('Santa María', 'Velero', 'CCC', 'Madera', '11m', '4m', '1.5', '2018-05-03'),
('Panzer III', 'Velero', 'DDD', 'Metal', '10m', '5m', '1.5', '2020-03-10'),
('Tempestad', 'Yate', 'EEE', 'Metal', '15m', '8m', '2m', '2015-05-10'),
('Tormenta', 'Yate', 'FFF', 'Metal', '15m', '8m', '2m', '2013-11-04'),
('Winchester', 'Velero', 'GGG', 'Madera/Metal', '10m', '5m', '1m', '1999-10-10'),
('Storm', 'Velero', 'HHH', 'Madera/Metal', '21m', '7m', '2m', '2004-10-10'),
('Trabant', 'Catamarán', 'III', 'Metal', '10', '6m', '1m', '2003-01-10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eslora`
--

CREATE TABLE `eslora` (
  `TipoEslora` char(1) NOT NULL,
  `CotaMenor` varchar(3) DEFAULT NULL,
  `CotaMayor` varchar(3) DEFAULT NULL,
  `Cantidad` varchar(100) DEFAULT NULL,
  `Precio` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `eslora`
--

INSERT INTO `eslora` (`TipoEslora`, `CotaMenor`, `CotaMayor`, `Cantidad`, `Precio`) VALUES
('C', '8m', '10m', '254', '200€'),
('D', '10m', '12m', '143', '275€'),
('F', '15m', '20m', '7', '1000€'),
('G', '20m', NULL, '2', '6500€');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `propiedad`
--

CREATE TABLE `propiedad` (
  `FechaInicio` date NOT NULL,
  `FechaFinal` date DEFAULT NULL,
  `IDPropiedad` varchar(25) NOT NULL,
  `IDLegal` varchar(25) NOT NULL,
  `Matrícula` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `propiedad`
--

INSERT INTO `propiedad` (`FechaInicio`, `FechaFinal`, `IDPropiedad`, `IDLegal`, `Matrícula`) VALUES
('2015-03-20', NULL, 'ZZZ1', '44444444A', 'EEE'),
('2019-04-20', NULL, 'ZZZ10', '33333333A', 'GGG'),
('2014-04-20', NULL, 'ZZZ11', '66666666A', 'III'),
('2017-01-20', NULL, 'ZZZ2', '44444444A', 'FFF'),
('2003-01-20', '2008-05-17', 'ZZZ3', '44444444A', 'BBB'),
('2003-01-20', NULL, 'ZZZ4', '11111111A', 'AAA'),
('2003-01-20', NULL, 'ZZZ5', '22222222A', 'BBB'),
('2003-01-20', NULL, 'ZZZ6', '33333333A', 'CCC'),
('2003-01-20', NULL, 'ZZZ7', '33333333A', 'DDD'),
('2003-01-20', '2010-10-05', 'ZZZ8', '55555555A', 'GGG'),
('2015-01-20', '2017-10-05', 'ZZZ9', '33333333A', 'HHH');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `FechaInicio` date NOT NULL,
  `FechaFinal` date NOT NULL,
  `IDRegistro` varchar(25) NOT NULL,
  `Identificador` varchar(25) NOT NULL,
  `Matrícula` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`FechaInicio`, `FechaFinal`, `IDRegistro`, `Identificador`, `Matrícula`) VALUES
('2020-05-02', '2020-06-20', 'YY1', '2A', 'BBB'),
('2020-03-12', '2020-10-08', 'YY10', '8A', 'III'),
('2020-03-01', '2020-03-03', 'YY2', '1A', 'AAA'),
('2020-03-01', '2020-07-03', 'YY3', '3A', 'DDD'),
('2020-04-02', '2020-10-01', 'YY4', '5A', 'EEE'),
('2020-02-02', '2020-04-20', 'YY5', '6A', 'FFF'),
('2004-02-04', '2006-06-20', 'YY6', '4A', 'GGG'),
('2020-04-04', '2020-05-05', 'YY7', '123', 'CCC'),
('2016-02-05', '2016-08-05', 'YY8', '7A', 'HHH'),
('2020-05-09', '2020-07-05', 'YY9', '4A', 'GGG');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `socio`
--

CREATE TABLE `socio` (
  `Nombre` varchar(50) DEFAULT NULL,
  `Nacionalidad` varchar(25) DEFAULT NULL,
  `IDLegal` varchar(50) NOT NULL,
  `Dirección` varchar(100) DEFAULT NULL,
  `Teléfono` varchar(25) DEFAULT NULL,
  `CuentaCorriente` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `socio`
--

INSERT INTO `socio` (`Nombre`, `Nacionalidad`, `IDLegal`, `Dirección`, `Teléfono`, `CuentaCorriente`) VALUES
('John Smith', 'UK', '11111111A', '1 Orchard St', '111 111 111', 'UK11111'),
('Richard Robinson', 'UK', '22222222A', '2 Orchard St', '222 222 222', 'UK22222'),
('Alustin Schneider', 'GER', '33333333A', '3 Orchard St', '333 333 333', 'GER33333'),
('Joan Ventura', 'ESP', '44444444A', '4 Orchard St', '444 444 444', 'ES44444'),
('Henri Polzin', 'GER', '55555555A', '5 Orchard St', '555 555 555', 'GER55555'),
('Toni Kroos', 'GER', '66666666A', '6 Orchard St', '666 666 666', 'GER66666');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `amarre`
--
ALTER TABLE `amarre`
  ADD PRIMARY KEY (`Identificador`),
  ADD KEY `TipoEslora` (`TipoEslora`);

--
-- Indices de la tabla `barco_motor`
--
ALTER TABLE `barco_motor`
  ADD PRIMARY KEY (`Matrícula`);

--
-- Indices de la tabla `barco_vela`
--
ALTER TABLE `barco_vela`
  ADD PRIMARY KEY (`Matrícula`);

--
-- Indices de la tabla `concesión`
--
ALTER TABLE `concesión`
  ADD PRIMARY KEY (`IDConcesión`),
  ADD KEY `IDLegal` (`IDLegal`),
  ADD KEY `Identificador` (`Identificador`);

--
-- Indices de la tabla `embarcación`
--
ALTER TABLE `embarcación`
  ADD PRIMARY KEY (`Matrícula`);

--
-- Indices de la tabla `eslora`
--
ALTER TABLE `eslora`
  ADD PRIMARY KEY (`TipoEslora`);

--
-- Indices de la tabla `propiedad`
--
ALTER TABLE `propiedad`
  ADD PRIMARY KEY (`IDPropiedad`),
  ADD KEY `IDLegal` (`IDLegal`),
  ADD KEY `Matrícula` (`Matrícula`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`IDRegistro`),
  ADD KEY `Identificador` (`Identificador`),
  ADD KEY `Matrícula` (`Matrícula`);

--
-- Indices de la tabla `socio`
--
ALTER TABLE `socio`
  ADD PRIMARY KEY (`IDLegal`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `amarre`
--
ALTER TABLE `amarre`
  ADD CONSTRAINT `amarre_ibfk_1` FOREIGN KEY (`TipoEslora`) REFERENCES `eslora` (`TipoEslora`);

--
-- Filtros para la tabla `barco_motor`
--
ALTER TABLE `barco_motor`
  ADD CONSTRAINT `barco_motor_ibfk_1` FOREIGN KEY (`Matrícula`) REFERENCES `embarcación` (`Matrícula`);

--
-- Filtros para la tabla `barco_vela`
--
ALTER TABLE `barco_vela`
  ADD CONSTRAINT `barco_vela_ibfk_1` FOREIGN KEY (`Matrícula`) REFERENCES `embarcación` (`Matrícula`);

--
-- Filtros para la tabla `concesión`
--
ALTER TABLE `concesión`
  ADD CONSTRAINT `concesión_ibfk_1` FOREIGN KEY (`IDLegal`) REFERENCES `socio` (`IDLegal`),
  ADD CONSTRAINT `concesión_ibfk_2` FOREIGN KEY (`Identificador`) REFERENCES `amarre` (`Identificador`);

--
-- Filtros para la tabla `propiedad`
--
ALTER TABLE `propiedad`
  ADD CONSTRAINT `propiedad_ibfk_1` FOREIGN KEY (`IDLegal`) REFERENCES `socio` (`IDLegal`),
  ADD CONSTRAINT `propiedad_ibfk_2` FOREIGN KEY (`Matrícula`) REFERENCES `embarcación` (`Matrícula`);

--
-- Filtros para la tabla `registro`
--
ALTER TABLE `registro`
  ADD CONSTRAINT `registro_ibfk_1` FOREIGN KEY (`Identificador`) REFERENCES `amarre` (`Identificador`),
  ADD CONSTRAINT `registro_ibfk_2` FOREIGN KEY (`Matrícula`) REFERENCES `embarcación` (`Matrícula`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
